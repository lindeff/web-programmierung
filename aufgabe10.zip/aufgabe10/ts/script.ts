const questionElement = document.getElementById("question")!;
const input = document.getElementById("name-input") as HTMLInputElement;

document.getElementById("name-form")?.addEventListener("submit", (event) => {
    event.preventDefault()
    questionElement.style.display = "none";

    document.getElementById("user-name").textContent = input.value;
    document.getElementById("greeting").style.display = "block";
});